<?php

return '简体中文';
